<!DOCTYPE html>

<meta charset="UTF-8">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="all_1.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />


</head>
<body>
  <span style="font-family:Microsoft JhengHei;">
<div id="header-wrapper">
  <div id="header" class="container">
    <div id="logo">
      <h1><a href="login.php">通識評價系統</a></h1>
    </div>
    <div id="menu3">
      <ul>
     
      </ul>
    </div>
  </div>
</div>
<div id="wrapper">
  <div id="staff" class="container">
<form action="check.php" method="post">

<h2>帳號
<input type="text" name="id"  style="height:25px;width:202px;font-size: 16px;font-family:Microsoft JhengHei;" placeholder="請輸入您的帳號(學號)"><br/></h2><br/>
<h2>密碼
<input type="password" name="pwd"style="height:25px;width:202px;font-size: 16px;font-family:Microsoft JhengHei;"  placeholder="請輸入您的密碼"></h2><br/>

<h3><a href='registerinput.php' >註冊</a></h3>

<blockquote><blockquote><blockquote><blockquote><blockquote><h3><input type="submit" value="登入" style="width: 60px;height: 30px;font-size:16px;font-family:Microsoft JhengHei;"></h3></blockquote><br/><br/>
</form>
      
  </div>
</div>

  <div id="page" class="container">

      </ul>
    </div>

        </li>
      </ul>
    </div>

      </ul>
    </div>
  </div>
</div>
<div id="welcome-wrapper">
  <div id="welcome" class="container">
    <div class="title">
      <h2>注意事項</h2>
    </div>
    <p>請勿留言不雅詞彙與不合乎事實之評論</strong>，否則將予以刪除並停用該帳號。 
</span>
</body>
</html>
